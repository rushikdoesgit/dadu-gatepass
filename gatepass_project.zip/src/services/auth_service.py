import jwt
from fastapi import HTTPException, status
from src.config import settings

# Initialize the JWK client
jwks_client = jwt.PyJWKClient(settings.SWD_JWKS_URL)

def verify_swd_token(token: str) -> dict:
    """
    Verifies the JWT token from SWD against their public JWKS.
    Returns the decoded token claims.
    """
    try:
        signing_key = jwks_client.get_signing_key_from_jwt(token)
        data = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            audience=settings.SWD_CLIENT_ID,
            issuer=settings.SWD_ISSUER
        )
        return data
    except jwt.exceptions.PyJWKClientError as e:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Failed to fetch signing keys from SWD identity provider."
        )
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired."
        )
    except jwt.InvalidTokenError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token."
        )
